#!/usr/bin/env bash
set -e
SCRIPT_DIR=$(dirname $(readlink -f $0))

source $SCRIPT_DIR/private/runner.env
source $SCRIPT_DIR/private/runner-secured.env

mkdir -p $SCRIPT_DIR/logs

if [ -f $SCRIPT_DIR/logs/runner.log ]; then
   mv $SCRIPT_DIR/logs/runner.log $SCRIPT_DIR/logs/runner-$(date +%Y-%m-%d-%H%M%S).log
fi

WORKSPACE_ROOT=$SCRIPT_DIR/workspaces
mkdir -p $WORKSPACE_ROOT

echo "Starting runner. Will log in $SCRIPT_DIR/logs/runner.log"

java -cp "$SCRIPT_DIR/config/:$SCRIPT_DIR/poom-ci-runners.jar" \
    -Dgh.pipeline.provider.workdir=$WORKSPACE_ROOT \
	org.codingmatters.poom.ci.runners.PoomCIRunner \
	&> $SCRIPT_DIR/logs/runner.log
