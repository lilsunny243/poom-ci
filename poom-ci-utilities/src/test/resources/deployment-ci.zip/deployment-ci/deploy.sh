#!/usr/bin/env bash

DEPLOY_DIR=$(dirname $(readlink -f $0))

STACK=ci

docker stack deploy $STACK \
    --with-registry-auth  \
    -c $DEPLOY_DIR/stack.yml \
    "$@"
