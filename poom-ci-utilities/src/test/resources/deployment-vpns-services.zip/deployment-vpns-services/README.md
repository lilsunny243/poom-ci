#deployment-vpns-services


### running vpn containers

**From externals environment**

First, run main.yml to deploy container's docker-compose.yml

Then start containers
````
cd /var/containers/openvpn
docker-compose up -d
````

### generate CA and server certs

Dans chaque nouveau container openvpn

##### generating CA certs

````
cd /opt/my_ca/

source ./vars
touch keys/index.txt
echo 01 > keys/serial
./build-ca
````

##### generating server certs

Allways choose 'server' name
Please set company name
Bien répondre 'y' explicitement aux deux dernières questions

````
./build-key-server server
````


##### generating dh
Take a long time (many minutes)
````
./build-dh
````

##### create empty crl
Fonctionne parfaitement malgré les messages d'erreur (TODO dirty)
````
./revoke-full keys/index.txt
````





### upgrading due to inventory changes

**From external environment**
- upgrade static clients configs
- upgrade iptable rules
- upgrade route registry service
- upgrade server configs
....

````
./main.sh -r deployment-vpns-services -s upgrade-config.yml
````

!!! You may have to restart containers manually in order to apply changes







##### generating key pair for 'box-erhard-1' client
Go inside openvpn container



````
docker exec -it openvpn_openvpn-erhard_1 bash
cd /opt/my_ca/
source ./vars
./build-key box-erhard-1
````
Keys are placed in 'keys' directory.

Files needed by client : CA public key (ca.crt), client public (.crt) and private key (.key).

### revoking certificate for 'toto' client

````
cd /opt/my_ca/
source ./vars
./revoke-full toto
````
This will display error but works fine, no need to restart openvpn service.


### display crl informations

````
openssl crl -in keys/crl.pem -text
````


### refresh crl

````
./revoke-full keys/index.txt
````
Fonctionne parfaitement malgré les messages d'erreur (TODO dirty)






