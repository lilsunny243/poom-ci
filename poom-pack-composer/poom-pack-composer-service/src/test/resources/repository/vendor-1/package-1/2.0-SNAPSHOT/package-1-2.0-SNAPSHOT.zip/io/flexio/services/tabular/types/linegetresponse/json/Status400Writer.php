<?php

namespace io\flexio\services\tabular\types\linegetresponse\json;

use io\flexio\services\tabular\types\linegetresponse\Status400;

class Status400Writer {

    public function write( Status400 $object ) : string {
        return json_encode( $object );
    }
}