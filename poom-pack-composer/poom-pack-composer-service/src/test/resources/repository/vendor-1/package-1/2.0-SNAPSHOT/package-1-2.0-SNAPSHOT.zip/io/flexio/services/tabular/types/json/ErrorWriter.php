<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\Error;

class ErrorWriter {

    public function write( Error $object ) : string {
        return json_encode( $object );
    }
}