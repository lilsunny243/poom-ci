<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\Tabular;

class TabularWriter {

    public function write( Tabular $object ) : string {
        return json_encode( $object );
    }
}