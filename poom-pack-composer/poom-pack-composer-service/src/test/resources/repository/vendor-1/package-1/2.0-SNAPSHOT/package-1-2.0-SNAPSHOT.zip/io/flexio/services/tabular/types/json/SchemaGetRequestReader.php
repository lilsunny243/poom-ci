<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\SchemaGetRequest;


class SchemaGetRequestReader {

    public function read( string $json ) : SchemaGetRequest {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : SchemaGetRequest {
        $schemaGetRequest = new SchemaGetRequest();
        if( isset( $decode['tabularId'] )){
            $schemaGetRequest->withTabularId( $decode['tabularId'] );
        }
        if( isset( $decode['account'] )){
            $schemaGetRequest->withAccount( $decode['account'] );
        }
        return $schemaGetRequest;
    }

}