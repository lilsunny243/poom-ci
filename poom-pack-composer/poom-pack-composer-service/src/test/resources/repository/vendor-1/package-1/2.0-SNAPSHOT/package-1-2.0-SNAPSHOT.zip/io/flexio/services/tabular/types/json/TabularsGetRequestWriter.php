<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsGetRequest;

class TabularsGetRequestWriter {

    public function write( TabularsGetRequest $object ) : string {
        return json_encode( $object );
    }
}