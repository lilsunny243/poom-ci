<?php

namespace io\flexio\services\tabular\types\schemagetresponse\json;

use io\flexio\services\tabular\types\schemagetresponse\Status404;

class Status404Writer {

    public function write( Status404 $object ) : string {
        return json_encode( $object );
    }
}