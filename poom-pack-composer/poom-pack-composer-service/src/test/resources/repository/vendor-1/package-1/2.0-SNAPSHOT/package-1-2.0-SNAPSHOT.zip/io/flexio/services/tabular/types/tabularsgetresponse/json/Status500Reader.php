<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\json;

use io\flexio\services\tabular\types\tabularsgetresponse\Status500;


class Status500Reader {

    public function read( string $json ) : Status500 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status500 {
        $status500 = new Status500();
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $status500->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status500;
    }

}