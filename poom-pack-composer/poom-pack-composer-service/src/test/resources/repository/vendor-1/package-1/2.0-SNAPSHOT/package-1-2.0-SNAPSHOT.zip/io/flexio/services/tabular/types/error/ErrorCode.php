<?php

namespace io\flexio\services\tabular\types\error;

use \Exception;

use \JsonSerializable;

class ErrorCode implements JsonSerializable {

    protected $value;

    private function __construct( $value ){
        $this->value = $value;
    }

    public function value(){
        return $this->value;
    }
    
    public static function ILLEGAL_RANGE_SPEC(): ErrorCode { 
        return new ErrorCode( 'ILLEGAL_RANGE_SPEC' );
    }

    public static function UNEXPECTED_ERROR(): ErrorCode { 
        return new ErrorCode( 'UNEXPECTED_ERROR' );
    }

    public static function RESOURCE_NOT_FOUND(): ErrorCode { 
        return new ErrorCode( 'RESOURCE_NOT_FOUND' );
    }

    public static function IMPOSSIBLE_CAST(): ErrorCode { 
        return new ErrorCode( 'IMPOSSIBLE_CAST' );
    }

    public static function INVALID_ACCOUNT(): ErrorCode { 
        return new ErrorCode( 'INVALID_ACCOUNT' );
    }

    public static function INVALID_RANGE(): ErrorCode { 
        return new ErrorCode( 'INVALID_RANGE' );
    }

    public static function valueOf( string $value ): ErrorCode {
        if( in_array($value, ErrorCode::values())){
            return new ErrorCode( $value );
        } else {
            throw new Exception( 'No enum constant '.$value );
        }
    }

    public static function values(){
        return array('ILLEGAL_RANGE_SPEC', 'UNEXPECTED_ERROR', 'RESOURCE_NOT_FOUND', 'IMPOSSIBLE_CAST', 'INVALID_ACCOUNT', 'INVALID_RANGE');
    }
    public function jsonSerialize() {
        return $this->value;
    }
}