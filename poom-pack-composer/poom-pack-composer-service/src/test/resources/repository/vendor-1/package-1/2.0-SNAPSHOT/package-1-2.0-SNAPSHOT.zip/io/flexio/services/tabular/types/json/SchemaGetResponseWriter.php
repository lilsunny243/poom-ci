<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\SchemaGetResponse;

class SchemaGetResponseWriter {

    public function write( SchemaGetResponse $object ) : string {
        return json_encode( $object );
    }
}