<?php

namespace io\flexio\services\tabular\api;

interface Line {

    public function lineGet( LineGetRequest $lineGetRequest ): LineGetResponse;

    
}