<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LinesGetRequest;

class LinesGetRequestWriter {

    public function write( LinesGetRequest $object ) : string {
        return json_encode( $object );
    }
}