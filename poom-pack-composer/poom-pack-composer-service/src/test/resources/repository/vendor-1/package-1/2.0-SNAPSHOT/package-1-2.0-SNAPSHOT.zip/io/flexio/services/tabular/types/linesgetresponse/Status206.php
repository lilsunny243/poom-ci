<?php

namespace io\flexio\services\tabular\types\linesgetresponse;


class Status206 implements \JsonSerializable {

    private $contentRange;
    private $acceptRange;
    private $payload;
    
    public function contentRange(): string {
        return $this->contentRange;
    }

    public function withContentRange(string $contentRange): Status206 {
        $this->contentRange = $contentRange;
        return $this;
    }

    public function acceptRange(): string {
        return $this->acceptRange;
    }

    public function withAcceptRange(string $acceptRange): Status206 {
        $this->acceptRange = $acceptRange;
        return $this;
    }

    public function payload(): \io\flexio\services\tabular\types\linesgetresponse\status206\Status206PayloadList {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\linesgetresponse\status206\Status206PayloadList $payload): Status206 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}