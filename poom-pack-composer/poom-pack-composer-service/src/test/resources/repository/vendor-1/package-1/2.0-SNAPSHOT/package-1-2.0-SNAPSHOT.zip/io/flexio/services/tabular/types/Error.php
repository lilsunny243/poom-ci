<?php

namespace io\flexio\services\tabular\types;


class Error implements \JsonSerializable {

    private $token;
    private $code;
    private $description;
    
    public function token(): string {
        return $this->token;
    }

    public function withToken(string $token): Error {
        $this->token = $token;
        return $this;
    }

    public function code(): \io\flexio\services\tabular\types\error\ErrorCode {
        return $this->code;
    }

    public function withCode(\io\flexio\services\tabular\types\error\ErrorCode $code): Error {
        $this->code = $code;
        return $this;
    }

    public function description(): string {
        return $this->description;
    }

    public function withDescription(string $description): Error {
        $this->description = $description;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}