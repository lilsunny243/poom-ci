<?php

namespace io\flexio\services\tabular\types\linesgetresponse\status206;

use io\flexio\utils\TypedArray;

class Status206PayloadList extends TypedArray {

    
    public function __construct( $input = array() ) {
        parent::__construct( function( array $item ){return $item;}, $input );
    }

    public function add(array $item) {
        parent::append( $item );
    }

}