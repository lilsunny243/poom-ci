<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LinesGetResponse;

class LinesGetResponseWriter {

    public function write( LinesGetResponse $object ) : string {
        return json_encode( $object );
    }
}