<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsGetResponse;


class TabularsGetResponseReader {

    public function read( string $json ) : TabularsGetResponse {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : TabularsGetResponse {
        $tabularsGetResponse = new TabularsGetResponse();
        if( isset( $decode['status200'] )){
            $reader = new \io\flexio\services\tabular\types\tabularsgetresponse\json\Status200Reader();
            $tabularsGetResponse->withStatus200( $reader->readArray( $decode['status200'] ));
        }
        if( isset( $decode['status206'] )){
            $reader = new \io\flexio\services\tabular\types\tabularsgetresponse\json\Status206Reader();
            $tabularsGetResponse->withStatus206( $reader->readArray( $decode['status206'] ));
        }
        if( isset( $decode['status416'] )){
            $reader = new \io\flexio\services\tabular\types\tabularsgetresponse\json\Status416Reader();
            $tabularsGetResponse->withStatus416( $reader->readArray( $decode['status416'] ));
        }
        if( isset( $decode['status404'] )){
            $reader = new \io\flexio\services\tabular\types\tabularsgetresponse\json\Status404Reader();
            $tabularsGetResponse->withStatus404( $reader->readArray( $decode['status404'] ));
        }
        if( isset( $decode['status500'] )){
            $reader = new \io\flexio\services\tabular\types\tabularsgetresponse\json\Status500Reader();
            $tabularsGetResponse->withStatus500( $reader->readArray( $decode['status500'] ));
        }
        return $tabularsGetResponse;
    }

}