<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status404;

class Status404Writer {

    public function write( Status404 $object ) : string {
        return json_encode( $object );
    }
}