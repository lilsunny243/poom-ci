<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status416;

class Status416Writer {

    public function write( Status416 $object ) : string {
        return json_encode( $object );
    }
}