<?php

namespace io\flexio\services\tabular\types\tabularspostresponse\json;

use io\flexio\services\tabular\types\tabularspostresponse\Status404;


class Status404Reader {

    public function read( string $json ) : Status404 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status404 {
        $status404 = new Status404();
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $status404->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status404;
    }

}