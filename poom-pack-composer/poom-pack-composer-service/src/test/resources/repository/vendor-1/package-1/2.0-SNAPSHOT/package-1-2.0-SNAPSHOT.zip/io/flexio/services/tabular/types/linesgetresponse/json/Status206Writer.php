<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status206;

class Status206Writer {

    public function write( Status206 $object ) : string {
        return json_encode( $object );
    }
}