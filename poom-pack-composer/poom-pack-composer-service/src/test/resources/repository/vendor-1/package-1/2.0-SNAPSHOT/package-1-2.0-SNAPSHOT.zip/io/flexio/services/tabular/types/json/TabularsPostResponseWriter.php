<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsPostResponse;

class TabularsPostResponseWriter {

    public function write( TabularsPostResponse $object ) : string {
        return json_encode( $object );
    }
}