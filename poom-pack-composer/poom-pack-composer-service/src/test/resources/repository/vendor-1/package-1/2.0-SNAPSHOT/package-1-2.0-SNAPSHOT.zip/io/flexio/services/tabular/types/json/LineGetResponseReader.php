<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LineGetResponse;


class LineGetResponseReader {

    public function read( string $json ) : LineGetResponse {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : LineGetResponse {
        $lineGetResponse = new LineGetResponse();
        if( isset( $decode['status200'] )){
            $reader = new \io\flexio\services\tabular\types\linegetresponse\json\Status200Reader();
            $lineGetResponse->withStatus200( $reader->readArray( $decode['status200'] ));
        }
        if( isset( $decode['status400'] )){
            $reader = new \io\flexio\services\tabular\types\linegetresponse\json\Status400Reader();
            $lineGetResponse->withStatus400( $reader->readArray( $decode['status400'] ));
        }
        if( isset( $decode['status404'] )){
            $reader = new \io\flexio\services\tabular\types\linegetresponse\json\Status404Reader();
            $lineGetResponse->withStatus404( $reader->readArray( $decode['status404'] ));
        }
        if( isset( $decode['status500'] )){
            $reader = new \io\flexio\services\tabular\types\linegetresponse\json\Status500Reader();
            $lineGetResponse->withStatus500( $reader->readArray( $decode['status500'] ));
        }
        return $lineGetResponse;
    }

}