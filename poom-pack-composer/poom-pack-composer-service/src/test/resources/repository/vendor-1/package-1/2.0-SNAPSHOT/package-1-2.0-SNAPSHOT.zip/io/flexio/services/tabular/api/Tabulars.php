<?php

namespace io\flexio\services\tabular\api;

interface Tabulars {

    public function lines(): Lines;

    public function tabularsPost( TabularsPostRequest $tabularsPostRequest ): TabularsPostResponse;

    public function tabularsGet( TabularsGetRequest $tabularsGetRequest ): TabularsGetResponse;

    
}