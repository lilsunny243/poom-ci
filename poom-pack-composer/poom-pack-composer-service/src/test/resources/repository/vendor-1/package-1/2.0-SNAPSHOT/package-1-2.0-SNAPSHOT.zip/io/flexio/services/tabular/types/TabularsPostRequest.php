<?php

namespace io\flexio\services\tabular\types;


class TabularsPostRequest implements \JsonSerializable {

    private $payload;
    private $account;
    
    public function payload(): \io\flexio\services\tabular\types\TabularCreation {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\TabularCreation $payload): TabularsPostRequest {
        $this->payload = $payload;
        return $this;
    }

    public function account(): string {
        return $this->account;
    }

    public function withAccount(string $account): TabularsPostRequest {
        $this->account = $account;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}