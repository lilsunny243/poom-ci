<?php

namespace io\flexio\services\tabular\types;


class SchemaGetRequest implements \JsonSerializable {

    private $tabularId;
    private $account;
    
    public function tabularId(): string {
        return $this->tabularId;
    }

    public function withTabularId(string $tabularId): SchemaGetRequest {
        $this->tabularId = $tabularId;
        return $this;
    }

    public function account(): string {
        return $this->account;
    }

    public function withAccount(string $account): SchemaGetRequest {
        $this->account = $account;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}