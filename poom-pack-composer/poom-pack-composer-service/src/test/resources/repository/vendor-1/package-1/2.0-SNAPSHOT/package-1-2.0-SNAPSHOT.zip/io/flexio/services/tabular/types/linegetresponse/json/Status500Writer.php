<?php

namespace io\flexio\services\tabular\types\linegetresponse\json;

use io\flexio\services\tabular\types\linegetresponse\Status500;

class Status500Writer {

    public function write( Status500 $object ) : string {
        return json_encode( $object );
    }
}