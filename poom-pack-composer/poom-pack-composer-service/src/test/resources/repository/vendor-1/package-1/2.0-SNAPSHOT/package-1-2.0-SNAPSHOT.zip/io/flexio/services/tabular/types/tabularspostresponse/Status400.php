<?php

namespace io\flexio\services\tabular\types\tabularspostresponse;


class Status400 implements \JsonSerializable {

    private $payload;
    
    public function payload(): \io\flexio\services\tabular\types\Error {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\Error $payload): Status400 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}