<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LinesGetRequest;


class LinesGetRequestReader {

    public function read( string $json ) : LinesGetRequest {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : LinesGetRequest {
        $linesGetRequest = new LinesGetRequest();
        if( isset( $decode['columnAs'] )){
            $list = new \io\flexio\services\tabular\types\linesgetrequest\LinesGetRequestColumnAsList();
            foreach( $decode['columnAs'] as $item ){
                $list[] = $item;
            }
            $linesGetRequest->withColumnAs( $list );
        }
        if( isset( $decode['failOnCastError'] )){
            $linesGetRequest->withFailOnCastError( $decode['failOnCastError'] );
        }
        if( isset( $decode['range'] )){
            $linesGetRequest->withRange( $decode['range'] );
        }
        if( isset( $decode['tabularId'] )){
            $linesGetRequest->withTabularId( $decode['tabularId'] );
        }
        if( isset( $decode['account'] )){
            $linesGetRequest->withAccount( $decode['account'] );
        }
        return $linesGetRequest;
    }

}