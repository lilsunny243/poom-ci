<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsPostResponse;


class TabularsPostResponseReader {

    public function read( string $json ) : TabularsPostResponse {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : TabularsPostResponse {
        $tabularsPostResponse = new TabularsPostResponse();
        if( isset( $decode['status201'] )){
            $reader = new \io\flexio\services\tabular\types\tabularspostresponse\json\Status201Reader();
            $tabularsPostResponse->withStatus201( $reader->readArray( $decode['status201'] ));
        }
        if( isset( $decode['status400'] )){
            $reader = new \io\flexio\services\tabular\types\tabularspostresponse\json\Status400Reader();
            $tabularsPostResponse->withStatus400( $reader->readArray( $decode['status400'] ));
        }
        if( isset( $decode['status404'] )){
            $reader = new \io\flexio\services\tabular\types\tabularspostresponse\json\Status404Reader();
            $tabularsPostResponse->withStatus404( $reader->readArray( $decode['status404'] ));
        }
        if( isset( $decode['status500'] )){
            $reader = new \io\flexio\services\tabular\types\tabularspostresponse\json\Status500Reader();
            $tabularsPostResponse->withStatus500( $reader->readArray( $decode['status500'] ));
        }
        return $tabularsPostResponse;
    }

}