<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsPostRequest;


class TabularsPostRequestReader {

    public function read( string $json ) : TabularsPostRequest {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : TabularsPostRequest {
        $tabularsPostRequest = new TabularsPostRequest();
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\TabularCreationReader();
            $tabularsPostRequest->withPayload( $reader->readArray( $decode['payload'] ));
        }
        if( isset( $decode['account'] )){
            $tabularsPostRequest->withAccount( $decode['account'] );
        }
        return $tabularsPostRequest;
    }

}