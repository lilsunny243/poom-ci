<?php

namespace io\flexio\services\tabular\types;


class SchemaGetResponse implements \JsonSerializable {

    private $status200;
    private $status404;
    private $status500;
    
    public function status200(): \io\flexio\services\tabular\types\schemagetresponse\Status200 {
        return $this->status200;
    }

    public function withStatus200(\io\flexio\services\tabular\types\schemagetresponse\Status200 $status200): SchemaGetResponse {
        $this->status200 = $status200;
        return $this;
    }

    public function status404(): \io\flexio\services\tabular\types\schemagetresponse\Status404 {
        return $this->status404;
    }

    public function withStatus404(\io\flexio\services\tabular\types\schemagetresponse\Status404 $status404): SchemaGetResponse {
        $this->status404 = $status404;
        return $this;
    }

    public function status500(): \io\flexio\services\tabular\types\schemagetresponse\Status500 {
        return $this->status500;
    }

    public function withStatus500(\io\flexio\services\tabular\types\schemagetresponse\Status500 $status500): SchemaGetResponse {
        $this->status500 = $status500;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}