<?php

namespace io\flexio\services\tabular\types;


class LinesGetResponse implements \JsonSerializable {

    private $status400;
    private $status200;
    private $status206;
    private $status416;
    private $status404;
    private $status500;
    
    public function status400(): \io\flexio\services\tabular\types\linesgetresponse\Status400 {
        return $this->status400;
    }

    public function withStatus400(\io\flexio\services\tabular\types\linesgetresponse\Status400 $status400): LinesGetResponse {
        $this->status400 = $status400;
        return $this;
    }

    public function status200(): \io\flexio\services\tabular\types\linesgetresponse\Status200 {
        return $this->status200;
    }

    public function withStatus200(\io\flexio\services\tabular\types\linesgetresponse\Status200 $status200): LinesGetResponse {
        $this->status200 = $status200;
        return $this;
    }

    public function status206(): \io\flexio\services\tabular\types\linesgetresponse\Status206 {
        return $this->status206;
    }

    public function withStatus206(\io\flexio\services\tabular\types\linesgetresponse\Status206 $status206): LinesGetResponse {
        $this->status206 = $status206;
        return $this;
    }

    public function status416(): \io\flexio\services\tabular\types\linesgetresponse\Status416 {
        return $this->status416;
    }

    public function withStatus416(\io\flexio\services\tabular\types\linesgetresponse\Status416 $status416): LinesGetResponse {
        $this->status416 = $status416;
        return $this;
    }

    public function status404(): \io\flexio\services\tabular\types\linesgetresponse\Status404 {
        return $this->status404;
    }

    public function withStatus404(\io\flexio\services\tabular\types\linesgetresponse\Status404 $status404): LinesGetResponse {
        $this->status404 = $status404;
        return $this;
    }

    public function status500(): \io\flexio\services\tabular\types\linesgetresponse\Status500 {
        return $this->status500;
    }

    public function withStatus500(\io\flexio\services\tabular\types\linesgetresponse\Status500 $status500): LinesGetResponse {
        $this->status500 = $status500;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}