<?php

namespace io\flexio\services\tabular\types\linegetresponse;


class Status200 implements \JsonSerializable {

    private $payload;
    
    public function payload(): array {
        return $this->payload;
    }

    public function withPayload(array $payload): Status200 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}