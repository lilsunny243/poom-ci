<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status200;


class Status200Reader {

    public function read( string $json ) : Status200 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status200 {
        $status200 = new Status200();
        if( isset( $decode['contentRange'] )){
            $status200->withContentRange( $decode['contentRange'] );
        }
        if( isset( $decode['acceptRange'] )){
            $status200->withAcceptRange( $decode['acceptRange'] );
        }
        if( isset( $decode['payload'] )){
            $list = new \io\flexio\services\tabular\types\linesgetresponse\status200\Status200PayloadList();
            foreach( $decode['payload'] as $item ){
                $list[] = $item;
            }
            $status200->withPayload( $list );
        }
        return $status200;
    }

}