<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status206;


class Status206Reader {

    public function read( string $json ) : Status206 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status206 {
        $status206 = new Status206();
        if( isset( $decode['contentRange'] )){
            $status206->withContentRange( $decode['contentRange'] );
        }
        if( isset( $decode['acceptRange'] )){
            $status206->withAcceptRange( $decode['acceptRange'] );
        }
        if( isset( $decode['payload'] )){
            $list = new \io\flexio\services\tabular\types\linesgetresponse\status206\Status206PayloadList();
            foreach( $decode['payload'] as $item ){
                $list[] = $item;
            }
            $status206->withPayload( $list );
        }
        return $status206;
    }

}