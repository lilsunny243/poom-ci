<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\SchemaGetRequest;

class SchemaGetRequestWriter {

    public function write( SchemaGetRequest $object ) : string {
        return json_encode( $object );
    }
}