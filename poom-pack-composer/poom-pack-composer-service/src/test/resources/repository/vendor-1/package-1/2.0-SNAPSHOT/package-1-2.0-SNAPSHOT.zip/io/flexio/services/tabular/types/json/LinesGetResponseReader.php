<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LinesGetResponse;


class LinesGetResponseReader {

    public function read( string $json ) : LinesGetResponse {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : LinesGetResponse {
        $linesGetResponse = new LinesGetResponse();
        if( isset( $decode['status400'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status400Reader();
            $linesGetResponse->withStatus400( $reader->readArray( $decode['status400'] ));
        }
        if( isset( $decode['status200'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status200Reader();
            $linesGetResponse->withStatus200( $reader->readArray( $decode['status200'] ));
        }
        if( isset( $decode['status206'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status206Reader();
            $linesGetResponse->withStatus206( $reader->readArray( $decode['status206'] ));
        }
        if( isset( $decode['status416'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status416Reader();
            $linesGetResponse->withStatus416( $reader->readArray( $decode['status416'] ));
        }
        if( isset( $decode['status404'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status404Reader();
            $linesGetResponse->withStatus404( $reader->readArray( $decode['status404'] ));
        }
        if( isset( $decode['status500'] )){
            $reader = new \io\flexio\services\tabular\types\linesgetresponse\json\Status500Reader();
            $linesGetResponse->withStatus500( $reader->readArray( $decode['status500'] ));
        }
        return $linesGetResponse;
    }

}