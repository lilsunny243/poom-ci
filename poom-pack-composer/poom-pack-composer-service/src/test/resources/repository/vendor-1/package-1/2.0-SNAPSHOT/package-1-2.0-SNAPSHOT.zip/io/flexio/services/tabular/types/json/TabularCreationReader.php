<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularCreation;


class TabularCreationReader {

    public function read( string $json ) : TabularCreation {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : TabularCreation {
        $tabularCreation = new TabularCreation();
        if( isset( $decode['columnNames'] )){
            $tabularCreation->withColumnNames( \io\flexio\services\tabular\types\tabularcreation\TabularCreationColumnNames::valueOf( $decode['columnNames'] ));
        }
        if( isset( $decode['objectStorageURI'] )){
            $tabularCreation->withObjectStorageURI( $decode['objectStorageURI'] );
        }
        if( isset( $decode['timeToLive'] )){
            $tabularCreation->withTimeToLive( $decode['timeToLive'] );
        }
        if( isset( $decode['charSeparator'] )){
            $tabularCreation->withCharSeparator( $decode['charSeparator'] );
        }
        return $tabularCreation;
    }

}