<?php

namespace io\flexio\services\tabular\types\linegetresponse\json;

use io\flexio\services\tabular\types\linegetresponse\Status200;


class Status200Reader {

    public function read( string $json ) : Status200 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status200 {
        $status200 = new Status200();
        if( isset( $decode['payload'] )){
            $status200->withPayload( $decode['payload'] );
        }
        return $status200;
    }

}