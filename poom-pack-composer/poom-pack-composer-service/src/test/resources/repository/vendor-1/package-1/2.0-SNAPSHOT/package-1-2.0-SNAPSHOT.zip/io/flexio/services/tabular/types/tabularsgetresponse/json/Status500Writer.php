<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\json;

use io\flexio\services\tabular\types\tabularsgetresponse\Status500;

class Status500Writer {

    public function write( Status500 $object ) : string {
        return json_encode( $object );
    }
}