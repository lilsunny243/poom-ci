<?php

namespace io\flexio\services\tabular\types;


class Tabular implements \JsonSerializable {

    private $name;
    private $type;
    private $expirationDate;
    private $nbLines;
    private $timeToLive;
    
    public function name(): string {
        return $this->name;
    }

    public function withName(string $name): Tabular {
        $this->name = $name;
        return $this;
    }

    public function type(): \io\flexio\services\tabular\types\tabular\TabularType {
        return $this->type;
    }

    public function withType(\io\flexio\services\tabular\types\tabular\TabularType $type): Tabular {
        $this->type = $type;
        return $this;
    }

    public function expirationDate(): \io\flexio\utils\FlexDate {
        return $this->expirationDate;
    }

    public function withExpirationDate(\io\flexio\utils\FlexDate $expirationDate): Tabular {
        $this->expirationDate = $expirationDate;
        return $this;
    }

    public function nbLines(): int {
        return $this->nbLines;
    }

    public function withNbLines(int $nbLines): Tabular {
        $this->nbLines = $nbLines;
        return $this;
    }

    public function timeToLive(): int {
        return $this->timeToLive;
    }

    public function withTimeToLive(int $timeToLive): Tabular {
        $this->timeToLive = $timeToLive;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}