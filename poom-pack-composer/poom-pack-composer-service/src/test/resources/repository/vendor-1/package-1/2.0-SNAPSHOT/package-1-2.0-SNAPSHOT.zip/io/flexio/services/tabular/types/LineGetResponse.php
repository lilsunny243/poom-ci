<?php

namespace io\flexio\services\tabular\types;


class LineGetResponse implements \JsonSerializable {

    private $status200;
    private $status400;
    private $status404;
    private $status500;
    
    public function status200(): \io\flexio\services\tabular\types\linegetresponse\Status200 {
        return $this->status200;
    }

    public function withStatus200(\io\flexio\services\tabular\types\linegetresponse\Status200 $status200): LineGetResponse {
        $this->status200 = $status200;
        return $this;
    }

    public function status400(): \io\flexio\services\tabular\types\linegetresponse\Status400 {
        return $this->status400;
    }

    public function withStatus400(\io\flexio\services\tabular\types\linegetresponse\Status400 $status400): LineGetResponse {
        $this->status400 = $status400;
        return $this;
    }

    public function status404(): \io\flexio\services\tabular\types\linegetresponse\Status404 {
        return $this->status404;
    }

    public function withStatus404(\io\flexio\services\tabular\types\linegetresponse\Status404 $status404): LineGetResponse {
        $this->status404 = $status404;
        return $this;
    }

    public function status500(): \io\flexio\services\tabular\types\linegetresponse\Status500 {
        return $this->status500;
    }

    public function withStatus500(\io\flexio\services\tabular\types\linegetresponse\Status500 $status500): LineGetResponse {
        $this->status500 = $status500;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}