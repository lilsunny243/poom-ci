<?php

namespace io\flexio\services\tabular\types\linegetresponse\json;

use io\flexio\services\tabular\types\linegetresponse\Status404;

class Status404Writer {

    public function write( Status404 $object ) : string {
        return json_encode( $object );
    }
}