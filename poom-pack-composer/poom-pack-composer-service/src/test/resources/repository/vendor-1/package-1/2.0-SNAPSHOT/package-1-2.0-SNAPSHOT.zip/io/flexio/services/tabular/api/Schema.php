<?php

namespace io\flexio\services\tabular\api;

interface Schema {

    public function schemaGet( SchemaGetRequest $schemaGetRequest ): SchemaGetResponse;

    
}