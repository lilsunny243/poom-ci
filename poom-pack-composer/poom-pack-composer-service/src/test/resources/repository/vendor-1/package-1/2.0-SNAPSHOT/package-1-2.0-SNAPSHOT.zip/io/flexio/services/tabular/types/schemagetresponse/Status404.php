<?php

namespace io\flexio\services\tabular\types\schemagetresponse;


class Status404 implements \JsonSerializable {

    private $payload;
    
    public function payload(): \io\flexio\services\tabular\types\Error {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\Error $payload): Status404 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}