<?php

namespace io\flexio\services\tabular\types;


class TabularsGetResponse implements \JsonSerializable {

    private $status200;
    private $status206;
    private $status416;
    private $status404;
    private $status500;
    
    public function status200(): \io\flexio\services\tabular\types\tabularsgetresponse\Status200 {
        return $this->status200;
    }

    public function withStatus200(\io\flexio\services\tabular\types\tabularsgetresponse\Status200 $status200): TabularsGetResponse {
        $this->status200 = $status200;
        return $this;
    }

    public function status206(): \io\flexio\services\tabular\types\tabularsgetresponse\Status206 {
        return $this->status206;
    }

    public function withStatus206(\io\flexio\services\tabular\types\tabularsgetresponse\Status206 $status206): TabularsGetResponse {
        $this->status206 = $status206;
        return $this;
    }

    public function status416(): \io\flexio\services\tabular\types\tabularsgetresponse\Status416 {
        return $this->status416;
    }

    public function withStatus416(\io\flexio\services\tabular\types\tabularsgetresponse\Status416 $status416): TabularsGetResponse {
        $this->status416 = $status416;
        return $this;
    }

    public function status404(): \io\flexio\services\tabular\types\tabularsgetresponse\Status404 {
        return $this->status404;
    }

    public function withStatus404(\io\flexio\services\tabular\types\tabularsgetresponse\Status404 $status404): TabularsGetResponse {
        $this->status404 = $status404;
        return $this;
    }

    public function status500(): \io\flexio\services\tabular\types\tabularsgetresponse\Status500 {
        return $this->status500;
    }

    public function withStatus500(\io\flexio\services\tabular\types\tabularsgetresponse\Status500 $status500): TabularsGetResponse {
        $this->status500 = $status500;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}