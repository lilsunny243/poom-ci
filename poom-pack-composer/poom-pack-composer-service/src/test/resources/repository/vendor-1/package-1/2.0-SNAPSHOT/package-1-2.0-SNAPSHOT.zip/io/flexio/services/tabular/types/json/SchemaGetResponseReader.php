<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\SchemaGetResponse;


class SchemaGetResponseReader {

    public function read( string $json ) : SchemaGetResponse {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : SchemaGetResponse {
        $schemaGetResponse = new SchemaGetResponse();
        if( isset( $decode['status200'] )){
            $reader = new \io\flexio\services\tabular\types\schemagetresponse\json\Status200Reader();
            $schemaGetResponse->withStatus200( $reader->readArray( $decode['status200'] ));
        }
        if( isset( $decode['status404'] )){
            $reader = new \io\flexio\services\tabular\types\schemagetresponse\json\Status404Reader();
            $schemaGetResponse->withStatus404( $reader->readArray( $decode['status404'] ));
        }
        if( isset( $decode['status500'] )){
            $reader = new \io\flexio\services\tabular\types\schemagetresponse\json\Status500Reader();
            $schemaGetResponse->withStatus500( $reader->readArray( $decode['status500'] ));
        }
        return $schemaGetResponse;
    }

}