<?php

namespace io\flexio\services\tabular\api;

use io\flexio\utils\http\HttpRequester;

class LineImpl implements Line {

    private $httpRequester;
    private $gatewayUrl;

    public function __construct( HttpRequester $httpRequester, string $gatewayUrl ){
        $this->httpRequester = $httpRequester;
        $this->gatewayUrl = $gatewayUrl;
    }

    public function lineGet( LineGetRequest $lineGetRequest ): LineGetResponse {
        $path = $this -> gatewayUrl.'/{account}/{tabularId}/{line}';
        $path = str_replace( '{line}', $lineGetRequest -> line(), $path );
        $this -> httpRequester -> path( $path );
        if( $lineGetRequest -> columnAs() !== null ){
            $this -> httpRequester -> arrayParameter( 'column-as', $lineGetRequest -> columnAs()->jsonSerialize() );
        }
        if( $lineGetRequest -> failOnCastError() !== null ){
            $this -> httpRequester -> parameter( 'failOnCastError', $lineGetRequest -> failOnCastError() ? 'true' : 'false' );
        }
        $responseDelegate = $this->httpRequester->get();

        $lineGetResponse = new LineGetResponse();
        if( $responseDelegate->code() == 200){
            $status = new \io\flexio\services\tabular\api\linegetresponse\Status200();
            $body = json_decode( $responseDelegate -> body(), true );
            $status -> withPayload( $body );
            $lineGetResponse -> withStatus200( $status );
        }
        if( $responseDelegate->code() == 400){
            $status = new \io\flexio\services\tabular\api\linegetresponse\Status400();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $lineGetResponse -> withStatus400( $status );
        }
        if( $responseDelegate->code() == 404){
            $status = new \io\flexio\services\tabular\api\linegetresponse\Status404();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $lineGetResponse -> withStatus404( $status );
        }
        if( $responseDelegate->code() == 500){
            $status = new \io\flexio\services\tabular\api\linegetresponse\Status500();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $lineGetResponse -> withStatus500( $status );
        }
        return $lineGetResponse;
    }

    
}