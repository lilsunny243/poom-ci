<?php

namespace io\flexio\services\tabular\api;

interface Lines {

    public function schema(): Schema;

    public function line(): Line;

    public function linesGet( LinesGetRequest $linesGetRequest ): LinesGetResponse;

    
}