<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsPostRequest;

class TabularsPostRequestWriter {

    public function write( TabularsPostRequest $object ) : string {
        return json_encode( $object );
    }
}