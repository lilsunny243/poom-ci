<?php

namespace io\flexio\services\tabular\types\tabularspostresponse\json;

use io\flexio\services\tabular\types\tabularspostresponse\Status201;


class Status201Reader {

    public function read( string $json ) : Status201 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status201 {
        $status201 = new Status201();
        if( isset( $decode['xEntityId'] )){
            $status201->withXEntityId( $decode['xEntityId'] );
        }
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\TabularReader();
            $status201->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status201;
    }

}