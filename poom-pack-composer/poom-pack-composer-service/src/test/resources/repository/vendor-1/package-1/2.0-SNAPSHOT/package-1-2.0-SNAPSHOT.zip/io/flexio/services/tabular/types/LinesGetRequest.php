<?php

namespace io\flexio\services\tabular\types;


class LinesGetRequest implements \JsonSerializable {

    private $columnAs;
    private $failOnCastError;
    private $range;
    private $tabularId;
    private $account;
    
    public function columnAs(): \io\flexio\services\tabular\types\linesgetrequest\LinesGetRequestColumnAsList {
        return $this->columnAs;
    }

    public function withColumnAs(\io\flexio\services\tabular\types\linesgetrequest\LinesGetRequestColumnAsList $columnAs): LinesGetRequest {
        $this->columnAs = $columnAs;
        return $this;
    }

    public function failOnCastError(): bool {
        return $this->failOnCastError;
    }

    public function withFailOnCastError(bool $failOnCastError): LinesGetRequest {
        $this->failOnCastError = $failOnCastError;
        return $this;
    }

    public function range(): string {
        return $this->range;
    }

    public function withRange(string $range): LinesGetRequest {
        $this->range = $range;
        return $this;
    }

    public function tabularId(): string {
        return $this->tabularId;
    }

    public function withTabularId(string $tabularId): LinesGetRequest {
        $this->tabularId = $tabularId;
        return $this;
    }

    public function account(): string {
        return $this->account;
    }

    public function withAccount(string $account): LinesGetRequest {
        $this->account = $account;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}