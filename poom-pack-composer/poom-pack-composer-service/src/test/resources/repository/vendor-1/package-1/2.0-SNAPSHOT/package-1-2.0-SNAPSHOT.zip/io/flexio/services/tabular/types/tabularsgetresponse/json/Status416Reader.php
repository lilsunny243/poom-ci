<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\json;

use io\flexio\services\tabular\types\tabularsgetresponse\Status416;


class Status416Reader {

    public function read( string $json ) : Status416 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status416 {
        $status416 = new Status416();
        if( isset( $decode['contentRange'] )){
            $status416->withContentRange( $decode['contentRange'] );
        }
        if( isset( $decode['acceptRange'] )){
            $status416->withAcceptRange( $decode['acceptRange'] );
        }
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $status416->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status416;
    }

}