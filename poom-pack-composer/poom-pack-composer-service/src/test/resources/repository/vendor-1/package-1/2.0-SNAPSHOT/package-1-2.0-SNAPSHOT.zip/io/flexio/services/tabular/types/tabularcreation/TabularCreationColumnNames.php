<?php

namespace io\flexio\services\tabular\types\tabularcreation;

use \Exception;

use \JsonSerializable;

class TabularCreationColumnNames implements JsonSerializable {

    protected $value;

    private function __construct( $value ){
        $this->value = $value;
    }

    public function value(){
        return $this->value;
    }
    
    public static function FIRSTLINE(): TabularCreationColumnNames { 
        return new TabularCreationColumnNames( 'FIRSTLINE' );
    }

    public static function INDEX(): TabularCreationColumnNames { 
        return new TabularCreationColumnNames( 'INDEX' );
    }

    public static function valueOf( string $value ): TabularCreationColumnNames {
        if( in_array($value, TabularCreationColumnNames::values())){
            return new TabularCreationColumnNames( $value );
        } else {
            throw new Exception( 'No enum constant '.$value );
        }
    }

    public static function values(){
        return array('FIRSTLINE', 'INDEX');
    }
    public function jsonSerialize() {
        return $this->value;
    }
}