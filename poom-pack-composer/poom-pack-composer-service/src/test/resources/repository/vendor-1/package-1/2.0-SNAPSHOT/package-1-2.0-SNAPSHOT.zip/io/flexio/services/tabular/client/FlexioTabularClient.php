<?php

namespace io\flexio\services\tabular\client;

interface FlexioTabularClient {

    public function tabulars(): \io\flexio\services\tabular\api\Tabulars;

    
}