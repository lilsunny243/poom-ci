<?php

namespace io\flexio\services\tabular\types;


class TabularsPostResponse implements \JsonSerializable {

    private $status201;
    private $status400;
    private $status404;
    private $status500;
    
    public function status201(): \io\flexio\services\tabular\types\tabularspostresponse\Status201 {
        return $this->status201;
    }

    public function withStatus201(\io\flexio\services\tabular\types\tabularspostresponse\Status201 $status201): TabularsPostResponse {
        $this->status201 = $status201;
        return $this;
    }

    public function status400(): \io\flexio\services\tabular\types\tabularspostresponse\Status400 {
        return $this->status400;
    }

    public function withStatus400(\io\flexio\services\tabular\types\tabularspostresponse\Status400 $status400): TabularsPostResponse {
        $this->status400 = $status400;
        return $this;
    }

    public function status404(): \io\flexio\services\tabular\types\tabularspostresponse\Status404 {
        return $this->status404;
    }

    public function withStatus404(\io\flexio\services\tabular\types\tabularspostresponse\Status404 $status404): TabularsPostResponse {
        $this->status404 = $status404;
        return $this;
    }

    public function status500(): \io\flexio\services\tabular\types\tabularspostresponse\Status500 {
        return $this->status500;
    }

    public function withStatus500(\io\flexio\services\tabular\types\tabularspostresponse\Status500 $status500): TabularsPostResponse {
        $this->status500 = $status500;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}