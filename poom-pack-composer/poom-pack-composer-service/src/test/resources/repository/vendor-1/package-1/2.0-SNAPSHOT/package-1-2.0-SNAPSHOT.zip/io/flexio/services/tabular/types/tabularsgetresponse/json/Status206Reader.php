<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\json;

use io\flexio\services\tabular\types\tabularsgetresponse\Status206;


class Status206Reader {

    public function read( string $json ) : Status206 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status206 {
        $status206 = new Status206();
        if( isset( $decode['contentRange'] )){
            $status206->withContentRange( $decode['contentRange'] );
        }
        if( isset( $decode['acceptRange'] )){
            $status206->withAcceptRange( $decode['acceptRange'] );
        }
        if( isset( $decode['payload'] )){
            $list = new \io\flexio\services\tabular\types\tabularsgetresponse\status206\Status206PayloadList();
            foreach( $decode['payload'] as $item ){
                $reader = new \io\flexio\services\tabular\types\json\TabularReader();
                $list[] = $reader->readArray( $item );
            }
            $status206->withPayload( $list );
        }
        return $status206;
    }

}