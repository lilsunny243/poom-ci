<?php

namespace io\flexio\services\tabular\api;

use io\flexio\utils\http\HttpRequester;

class TabularsImpl implements Tabulars {

    private $httpRequester;
    private $gatewayUrl;

    private $lines;

    public function __construct( HttpRequester $httpRequester, string $gatewayUrl ){
        $this->httpRequester = $httpRequester;
        $this->gatewayUrl = $gatewayUrl;
        $this->lines = new LinesImpl( $httpRequester, $gatewayUrl );
    }

    public function lines(): Lines{
        return $this->lines;
    }

    public function tabularsPost( TabularsPostRequest $tabularsPostRequest ): TabularsPostResponse {
        $path = $this -> gatewayUrl.'/{account}';
        $path = str_replace( '{account}', $tabularsPostRequest -> account(), $path );
        $this -> httpRequester -> path( $path );
        $content = json_encode( $tabularsPostRequest -> payload() );
        $contentType = 'application/json';
        $responseDelegate = $this->httpRequester->post( $contentType, $content );

        $tabularsPostResponse = new TabularsPostResponse();
        if( $responseDelegate->code() == 201){
            $status = new \io\flexio\services\tabular\api\tabularspostresponse\Status201();
            $reader = new \io\flexio\services\tabular\types\json\TabularReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $status -> withXEntityId( $responseDelegate -> header('X-entity-id')[0] );
            $tabularsPostResponse -> withStatus201( $status );
        }
        if( $responseDelegate->code() == 400){
            $status = new \io\flexio\services\tabular\api\tabularspostresponse\Status400();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $tabularsPostResponse -> withStatus400( $status );
        }
        if( $responseDelegate->code() == 404){
            $status = new \io\flexio\services\tabular\api\tabularspostresponse\Status404();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $tabularsPostResponse -> withStatus404( $status );
        }
        if( $responseDelegate->code() == 500){
            $status = new \io\flexio\services\tabular\api\tabularspostresponse\Status500();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $tabularsPostResponse -> withStatus500( $status );
        }
        return $tabularsPostResponse;
    }

    public function tabularsGet( TabularsGetRequest $tabularsGetRequest ): TabularsGetResponse {
        $path = $this -> gatewayUrl.'/{account}';
        $path = str_replace( '{account}', $tabularsGetRequest -> account(), $path );
        $this -> httpRequester -> path( $path );
        if( $tabularsGetRequest -> range() !== null ){
            $this -> httpRequester -> header( 'range', $tabularsGetRequest -> range() );
        }
        $responseDelegate = $this->httpRequester->get();

        $tabularsGetResponse = new TabularsGetResponse();
        if( $responseDelegate->code() == 200){
            $status = new \io\flexio\services\tabular\api\tabularsgetresponse\Status200();
            $reader = new \io\flexio\services\tabular\types\json\TabularReader();
            $body = json_decode( $responseDelegate -> body(), true );
            $list = new \io\flexio\services\tabular\api\tabularsgetresponse\status200\Status200PayloadList();
            foreach( $body as $item ) {
                $list[] = $reader->readArray( $item );
            }
            $status->withPayload( $list );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $tabularsGetResponse -> withStatus200( $status );
        }
        if( $responseDelegate->code() == 206){
            $status = new \io\flexio\services\tabular\api\tabularsgetresponse\Status206();
            $reader = new \io\flexio\services\tabular\types\json\TabularReader();
            $body = json_decode( $responseDelegate -> body(), true );
            $list = new \io\flexio\services\tabular\api\tabularsgetresponse\status206\Status206PayloadList();
            foreach( $body as $item ) {
                $list[] = $reader->readArray( $item );
            }
            $status->withPayload( $list );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $tabularsGetResponse -> withStatus206( $status );
        }
        if( $responseDelegate->code() == 416){
            $status = new \io\flexio\services\tabular\api\tabularsgetresponse\Status416();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $tabularsGetResponse -> withStatus416( $status );
        }
        if( $responseDelegate->code() == 404){
            $status = new \io\flexio\services\tabular\api\tabularsgetresponse\Status404();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $tabularsGetResponse -> withStatus404( $status );
        }
        if( $responseDelegate->code() == 500){
            $status = new \io\flexio\services\tabular\api\tabularsgetresponse\Status500();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $tabularsGetResponse -> withStatus500( $status );
        }
        return $tabularsGetResponse;
    }

    
}