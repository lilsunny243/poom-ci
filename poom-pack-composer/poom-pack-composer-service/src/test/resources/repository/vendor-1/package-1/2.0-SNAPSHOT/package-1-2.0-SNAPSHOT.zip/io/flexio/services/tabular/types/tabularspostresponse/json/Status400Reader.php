<?php

namespace io\flexio\services\tabular\types\tabularspostresponse\json;

use io\flexio\services\tabular\types\tabularspostresponse\Status400;


class Status400Reader {

    public function read( string $json ) : Status400 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status400 {
        $status400 = new Status400();
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $status400->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status400;
    }

}