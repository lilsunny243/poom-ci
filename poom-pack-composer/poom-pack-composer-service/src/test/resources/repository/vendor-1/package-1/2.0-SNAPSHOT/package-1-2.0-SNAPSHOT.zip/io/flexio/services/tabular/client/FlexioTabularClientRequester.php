<?php

namespace io\flexio\services\tabular\client;

class FlexioTabularClientRequester implements \io\flexio\services\tabular\client\FlexioTabularClient {

    private $tabulars;
    
    public function __construct( \io\flexio\utils\http\HttpRequester $requester, string $gatewayUrl ) {
        $this -> tabulars = new \io\flexio\services\tabular\api\TabularsImpl( $requester, $gatewayUrl );
    }

    public function tabulars(): \io\flexio\services\tabular\api\Tabulars {
        return $this -> tabulars;
    }
}