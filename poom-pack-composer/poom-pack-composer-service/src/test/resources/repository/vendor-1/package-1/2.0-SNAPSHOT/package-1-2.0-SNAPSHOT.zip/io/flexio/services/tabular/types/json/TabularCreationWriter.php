<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularCreation;

class TabularCreationWriter {

    public function write( TabularCreation $object ) : string {
        return json_encode( $object );
    }
}