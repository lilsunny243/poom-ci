<?php

namespace io\flexio\services\tabular\types\schemagetresponse\json;

use io\flexio\services\tabular\types\schemagetresponse\Status200;

class Status200Writer {

    public function write( Status200 $object ) : string {
        return json_encode( $object );
    }
}