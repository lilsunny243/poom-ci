<?php

namespace io\flexio\services\tabular\types\tabular;

use \Exception;

use \JsonSerializable;

class TabularType implements JsonSerializable {

    protected $value;

    private function __construct( $value ){
        $this->value = $value;
    }

    public function value(){
        return $this->value;
    }
    
    public static function XLS(): TabularType { 
        return new TabularType( 'XLS' );
    }

    public static function CSV(): TabularType { 
        return new TabularType( 'CSV' );
    }

    public static function valueOf( string $value ): TabularType {
        if( in_array($value, TabularType::values())){
            return new TabularType( $value );
        } else {
            throw new Exception( 'No enum constant '.$value );
        }
    }

    public static function values(){
        return array('XLS', 'CSV');
    }
    public function jsonSerialize() {
        return $this->value;
    }
}