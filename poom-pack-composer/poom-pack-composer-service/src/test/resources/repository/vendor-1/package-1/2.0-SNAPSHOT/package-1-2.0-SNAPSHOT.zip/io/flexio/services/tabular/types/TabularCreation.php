<?php

namespace io\flexio\services\tabular\types;


class TabularCreation implements \JsonSerializable {

    private $columnNames;
    private $objectStorageURI;
    private $timeToLive;
    private $charSeparator;
    
    public function columnNames(): \io\flexio\services\tabular\types\tabularcreation\TabularCreationColumnNames {
        return $this->columnNames;
    }

    public function withColumnNames(\io\flexio\services\tabular\types\tabularcreation\TabularCreationColumnNames $columnNames): TabularCreation {
        $this->columnNames = $columnNames;
        return $this;
    }

    public function objectStorageURI(): string {
        return $this->objectStorageURI;
    }

    public function withObjectStorageURI(string $objectStorageURI): TabularCreation {
        $this->objectStorageURI = $objectStorageURI;
        return $this;
    }

    public function timeToLive(): int {
        return $this->timeToLive;
    }

    public function withTimeToLive(int $timeToLive): TabularCreation {
        $this->timeToLive = $timeToLive;
        return $this;
    }

    public function charSeparator(): string {
        return $this->charSeparator;
    }

    public function withCharSeparator(string $charSeparator): TabularCreation {
        $this->charSeparator = $charSeparator;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}