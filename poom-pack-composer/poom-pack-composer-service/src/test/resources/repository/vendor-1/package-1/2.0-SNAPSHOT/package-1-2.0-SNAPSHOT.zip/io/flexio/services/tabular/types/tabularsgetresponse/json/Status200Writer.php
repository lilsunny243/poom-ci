<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\json;

use io\flexio\services\tabular\types\tabularsgetresponse\Status200;

class Status200Writer {

    public function write( Status200 $object ) : string {
        return json_encode( $object );
    }
}