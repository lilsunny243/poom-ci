<?php

namespace io\flexio\services\tabular\types\tabularspostresponse\json;

use io\flexio\services\tabular\types\tabularspostresponse\Status201;

class Status201Writer {

    public function write( Status201 $object ) : string {
        return json_encode( $object );
    }
}