<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\LineGetRequest;


class LineGetRequestReader {

    public function read( string $json ) : LineGetRequest {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : LineGetRequest {
        $lineGetRequest = new LineGetRequest();
        if( isset( $decode['columnAs'] )){
            $list = new \io\flexio\services\tabular\types\linegetrequest\LineGetRequestColumnAsList();
            foreach( $decode['columnAs'] as $item ){
                $list[] = $item;
            }
            $lineGetRequest->withColumnAs( $list );
        }
        if( isset( $decode['failOnCastError'] )){
            $lineGetRequest->withFailOnCastError( $decode['failOnCastError'] );
        }
        if( isset( $decode['line'] )){
            $lineGetRequest->withLine( $decode['line'] );
        }
        if( isset( $decode['tabularId'] )){
            $lineGetRequest->withTabularId( $decode['tabularId'] );
        }
        if( isset( $decode['account'] )){
            $lineGetRequest->withAccount( $decode['account'] );
        }
        return $lineGetRequest;
    }

}