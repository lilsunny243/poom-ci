<?php

namespace io\flexio\services\tabular\api;

use io\flexio\utils\http\HttpRequester;

class LinesImpl implements Lines {

    private $httpRequester;
    private $gatewayUrl;

    private $schema;

    private $line;

    public function __construct( HttpRequester $httpRequester, string $gatewayUrl ){
        $this->httpRequester = $httpRequester;
        $this->gatewayUrl = $gatewayUrl;
        $this->schema = new SchemaImpl( $httpRequester, $gatewayUrl );
        $this->line = new LineImpl( $httpRequester, $gatewayUrl );
    }

    public function schema(): Schema{
        return $this->schema;
    }

    public function line(): Line{
        return $this->line;
    }

    public function linesGet( LinesGetRequest $linesGetRequest ): LinesGetResponse {
        $path = $this -> gatewayUrl.'/{account}/{tabularId}';
        $path = str_replace( '{tabularId}', $linesGetRequest -> tabularId(), $path );
        $this -> httpRequester -> path( $path );
        if( $linesGetRequest -> columnAs() !== null ){
            $this -> httpRequester -> arrayParameter( 'column-as', $linesGetRequest -> columnAs()->jsonSerialize() );
        }
        if( $linesGetRequest -> failOnCastError() !== null ){
            $this -> httpRequester -> parameter( 'failOnCastError', $linesGetRequest -> failOnCastError() ? 'true' : 'false' );
        }
        if( $linesGetRequest -> range() !== null ){
            $this -> httpRequester -> header( 'range', $linesGetRequest -> range() );
        }
        $responseDelegate = $this->httpRequester->get();

        $linesGetResponse = new LinesGetResponse();
        if( $responseDelegate->code() == 400){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status400();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $linesGetResponse -> withStatus400( $status );
        }
        if( $responseDelegate->code() == 200){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status200();
            $body = json_decode( $responseDelegate -> body(), true );
            $list = new \io\flexio\services\tabular\api\linesgetresponse\status200\Status200PayloadList( $body );
            $status -> withPayload( $list );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $linesGetResponse -> withStatus200( $status );
        }
        if( $responseDelegate->code() == 206){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status206();
            $body = json_decode( $responseDelegate -> body(), true );
            $list = new \io\flexio\services\tabular\api\linesgetresponse\status206\Status206PayloadList( $body );
            $status -> withPayload( $list );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $linesGetResponse -> withStatus206( $status );
        }
        if( $responseDelegate->code() == 416){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status416();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $status -> withContentRange( $responseDelegate -> header('Content-Range')[0] );
            $status -> withAcceptRange( $responseDelegate -> header('Accept-Range')[0] );
            $linesGetResponse -> withStatus416( $status );
        }
        if( $responseDelegate->code() == 404){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status404();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $linesGetResponse -> withStatus404( $status );
        }
        if( $responseDelegate->code() == 500){
            $status = new \io\flexio\services\tabular\api\linesgetresponse\Status500();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $linesGetResponse -> withStatus500( $status );
        }
        return $linesGetResponse;
    }

    
}