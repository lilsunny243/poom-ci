<?php

namespace io\flexio\services\tabular\api;

use io\flexio\utils\http\HttpRequester;

class SchemaImpl implements Schema {

    private $httpRequester;
    private $gatewayUrl;

    public function __construct( HttpRequester $httpRequester, string $gatewayUrl ){
        $this->httpRequester = $httpRequester;
        $this->gatewayUrl = $gatewayUrl;
    }

    public function schemaGet( SchemaGetRequest $schemaGetRequest ): SchemaGetResponse {
        $path = $this -> gatewayUrl.'/{account}/{tabularId}/schema';
        $this -> httpRequester -> path( $path );
        $responseDelegate = $this->httpRequester->get();

        $schemaGetResponse = new SchemaGetResponse();
        if( $responseDelegate->code() == 200){
            $status = new \io\flexio\services\tabular\api\schemagetresponse\Status200();
            $reader = new \io\flexio\services\tabular\types\json\SchemaReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $schemaGetResponse -> withStatus200( $status );
        }
        if( $responseDelegate->code() == 404){
            $status = new \io\flexio\services\tabular\api\schemagetresponse\Status404();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $schemaGetResponse -> withStatus404( $status );
        }
        if( $responseDelegate->code() == 500){
            $status = new \io\flexio\services\tabular\api\schemagetresponse\Status500();
            $reader = new \io\flexio\services\tabular\types\json\ErrorReader();
            $body = $reader -> read( $responseDelegate->body() );
            $status -> withPayload( $body );
            $schemaGetResponse -> withStatus500( $status );
        }
        return $schemaGetResponse;
    }

    
}