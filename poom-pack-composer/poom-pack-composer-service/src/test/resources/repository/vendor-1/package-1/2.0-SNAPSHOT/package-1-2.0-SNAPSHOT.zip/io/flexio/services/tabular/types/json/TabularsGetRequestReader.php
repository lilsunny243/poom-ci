<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsGetRequest;


class TabularsGetRequestReader {

    public function read( string $json ) : TabularsGetRequest {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : TabularsGetRequest {
        $tabularsGetRequest = new TabularsGetRequest();
        if( isset( $decode['range'] )){
            $tabularsGetRequest->withRange( $decode['range'] );
        }
        if( isset( $decode['account'] )){
            $tabularsGetRequest->withAccount( $decode['account'] );
        }
        return $tabularsGetRequest;
    }

}