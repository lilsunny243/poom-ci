<?php

namespace io\flexio\services\tabular\types\schemagetresponse\json;

use io\flexio\services\tabular\types\schemagetresponse\Status200;


class Status200Reader {

    public function read( string $json ) : Status200 {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Status200 {
        $status200 = new Status200();
        if( isset( $decode['payload'] )){
            $reader = new \io\flexio\services\resources\api\types\json\SchemaReader();
            $status200->withPayload( $reader->readArray( $decode['payload'] ));
        }
        return $status200;
    }

}