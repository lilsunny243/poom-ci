<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\Error;


class ErrorReader {

    public function read( string $json ) : Error {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Error {
        $error = new Error();
        if( isset( $decode['token'] )){
            $error->withToken( $decode['token'] );
        }
        if( isset( $decode['code'] )){
            $error->withCode( \io\flexio\services\tabular\types\error\ErrorCode::valueOf( $decode['code'] ));
        }
        if( isset( $decode['description'] )){
            $error->withDescription( $decode['description'] );
        }
        return $error;
    }

}