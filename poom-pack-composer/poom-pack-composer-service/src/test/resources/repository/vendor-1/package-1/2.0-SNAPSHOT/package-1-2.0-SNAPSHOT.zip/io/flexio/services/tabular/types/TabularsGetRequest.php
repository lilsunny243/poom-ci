<?php

namespace io\flexio\services\tabular\types;


class TabularsGetRequest implements \JsonSerializable {

    private $range;
    private $account;
    
    public function range(): string {
        return $this->range;
    }

    public function withRange(string $range): TabularsGetRequest {
        $this->range = $range;
        return $this;
    }

    public function account(): string {
        return $this->account;
    }

    public function withAccount(string $account): TabularsGetRequest {
        $this->account = $account;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}