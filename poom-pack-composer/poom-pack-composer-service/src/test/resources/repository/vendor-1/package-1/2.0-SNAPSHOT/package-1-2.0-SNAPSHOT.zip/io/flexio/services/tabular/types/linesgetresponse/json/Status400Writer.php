<?php

namespace io\flexio\services\tabular\types\linesgetresponse\json;

use io\flexio\services\tabular\types\linesgetresponse\Status400;

class Status400Writer {

    public function write( Status400 $object ) : string {
        return json_encode( $object );
    }
}