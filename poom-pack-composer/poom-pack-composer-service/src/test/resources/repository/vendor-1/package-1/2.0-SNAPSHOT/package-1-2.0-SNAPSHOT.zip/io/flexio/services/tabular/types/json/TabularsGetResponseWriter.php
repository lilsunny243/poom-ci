<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\TabularsGetResponse;

class TabularsGetResponseWriter {

    public function write( TabularsGetResponse $object ) : string {
        return json_encode( $object );
    }
}