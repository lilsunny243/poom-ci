<?php

namespace io\flexio\services\tabular\types\tabularspostresponse;


class Status201 implements \JsonSerializable {

    private $xEntityId;
    private $payload;
    
    public function xEntityId(): string {
        return $this->xEntityId;
    }

    public function withXEntityId(string $xEntityId): Status201 {
        $this->xEntityId = $xEntityId;
        return $this;
    }

    public function payload(): \io\flexio\services\tabular\types\Tabular {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\Tabular $payload): Status201 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}