<?php

namespace io\flexio\services\tabular\types\json;

use io\flexio\services\tabular\types\Tabular;


class TabularReader {

    public function read( string $json ) : Tabular {
        $decode = json_decode( $json, true );
        return $this->readArray( $decode );
    }

    public function readArray( array $decode ) : Tabular {
        $tabular = new Tabular();
        if( isset( $decode['name'] )){
            $tabular->withName( $decode['name'] );
        }
        if( isset( $decode['type'] )){
            $tabular->withType( \io\flexio\services\tabular\types\tabular\TabularType::valueOf( $decode['type'] ));
        }
        if( isset( $decode['expirationDate'] )){
            $tabular->withExpirationDate( \io\flexio\utils\FlexDate::parse( $decode['expirationDate'] ));
        }
        if( isset( $decode['nbLines'] )){
            $tabular->withNbLines( $decode['nbLines'] );
        }
        if( isset( $decode['timeToLive'] )){
            $tabular->withTimeToLive( $decode['timeToLive'] );
        }
        return $tabular;
    }

}