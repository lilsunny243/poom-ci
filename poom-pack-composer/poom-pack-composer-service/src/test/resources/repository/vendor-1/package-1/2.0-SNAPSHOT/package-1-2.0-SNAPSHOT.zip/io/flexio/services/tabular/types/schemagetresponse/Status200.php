<?php

namespace io\flexio\services\tabular\types\schemagetresponse;


class Status200 implements \JsonSerializable {

    private $payload;
    
    public function payload(): \io\flexio\services\resources\api\types\Schema {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\resources\api\types\Schema $payload): Status200 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}