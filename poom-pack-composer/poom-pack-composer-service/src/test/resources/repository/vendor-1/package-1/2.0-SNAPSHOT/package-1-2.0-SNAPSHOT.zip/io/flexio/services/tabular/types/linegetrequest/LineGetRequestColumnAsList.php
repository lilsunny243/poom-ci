<?php

namespace io\flexio\services\tabular\types\linegetrequest;

use io\flexio\utils\TypedArray;

class LineGetRequestColumnAsList extends TypedArray {

    
    public function __construct( $input = array() ) {
        parent::__construct( function( string $item ){return strval( $item );}, $input );
    }

    public function add(string $item) {
        parent::append( $item );
    }

}