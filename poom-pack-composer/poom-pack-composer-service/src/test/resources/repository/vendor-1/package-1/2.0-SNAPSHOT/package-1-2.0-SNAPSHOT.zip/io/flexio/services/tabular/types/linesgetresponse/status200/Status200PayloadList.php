<?php

namespace io\flexio\services\tabular\types\linesgetresponse\status200;

use io\flexio\utils\TypedArray;

class Status200PayloadList extends TypedArray {

    
    public function __construct( $input = array() ) {
        parent::__construct( function( array $item ){return $item;}, $input );
    }

    public function add(array $item) {
        parent::append( $item );
    }

}