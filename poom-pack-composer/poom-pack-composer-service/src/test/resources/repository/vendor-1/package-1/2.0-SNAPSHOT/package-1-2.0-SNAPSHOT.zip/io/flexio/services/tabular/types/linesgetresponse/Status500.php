<?php

namespace io\flexio\services\tabular\types\linesgetresponse;


class Status500 implements \JsonSerializable {

    private $payload;
    
    public function payload(): \io\flexio\services\tabular\types\Error {
        return $this->payload;
    }

    public function withPayload(\io\flexio\services\tabular\types\Error $payload): Status500 {
        $this->payload = $payload;
        return $this;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}