<?php

namespace io\flexio\services\tabular\types\tabularsgetresponse\status200;

use io\flexio\utils\TypedArray;
use io\flexio\services\tabular\types\Tabular;

class Status200PayloadList extends TypedArray {

    
    public function __construct( $input = array() ) {
        parent::__construct( function( Tabular $item ){return $item;}, $input );
    }

    public function add(Tabular $item) {
        parent::append( $item );
    }

}